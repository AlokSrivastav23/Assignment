let btn=document.getElementById("btn");
btn.addEventListener('click',function(){
    let sentence = document.getElementById('sentence').value;
let letter = document.getElementById('letter').value;
let result = sentence.indexOf(letter);
let res="";
for(let i=result+1;i<sentence.length;i++)
{
res+=sentence[i];
}

document.getElementById("demo").innerHTML = res;
    
})